import './TagsModal.scss'
import React from 'react'

import { format, getTranslations } from '@gtm-av/js-i18n'
import { NikeButton, NikeModal, NikeIcon, NikeFlyout } from '@gtm-styleguide/react-styleguide'
import { AVThreeColumnLayout } from '@gtm-av/av-react-components'
import { loadAll, referenceData } from '@gtm-av/av-reference-data'
import { forEach, filter } from '@gtm-av/js-iterators'
import { TagTypes } from './TagTypes'
import { FlowSelector } from './FlowSelector/FlowSelector'
import { ClusterSelector } from './ClusterSelector/ClusterSelector'

import { sortTagsAlphabetically } from '../../utils/sort'

let state = {}
let summaryTooltip = null

export const openTagsModal = (seasonCode, regionId, marketplaceId, bannerAccountCode, retailConceptCode, selection, updateView, boardId) => {
  const prepareInitialTagCloudOptions = (currentFilters) => {
    const tags = getPossibleChannelHierarchyTags()

    return getFilteredChannelHierarchyTags(tags, currentFilters)
  }

  const getFilteredChannelHierarchyTags = (tags, currentFilters) => {
    const selectedTierIds = currentFilters ? currentFilters.tiers : []
    // const selectedStoreLevelCodes = currentFilters ? currentFilters.levels : []
    const selectedAssortmentFocusCodes = currentFilters ? currentFilters.assortmentFocuses : []
    const selectedChannelCodes = currentFilters ? currentFilters.channels : []
    const selectedMCA = currentFilters ? currentFilters.mca : false
    const searchCriteria = currentFilters ? currentFilters.search : ''
    const areSelectionsMade = selectedChannelCodes.length > 0 || selectedAssortmentFocusCodes.length > 0 || selectedTierIds.length > 0

    const filteredTags = []

    if (areSelectionsMade) {
      forEach(tags, (tag) => {
        let isSelectedChannel = selectedChannelCodes.length < 1 || (tag.channel && selectedChannelCodes.includes(tag.channel.code))
        let isSelectedTier = selectedTierIds.length < 1 || (tag.tier && selectedTierIds.includes(tag.tier.id))
        // let isSelectedStoreLevel = selectedStoreLevelCodes.length < 1 || (tag.storeLevel && selectedStoreLevelCodes.includes(tag.storeLevel.code))
        let isSelectedMCAStatus = tag.isMCA === selectedMCA

        if (isSelectedChannel && isSelectedAssortmentFocus(selectedAssortmentFocusCodes, tag) && isSelectedTier &&
          isSelectedMCAStatus && isSearchMatch(searchCriteria, tag)) {
          filteredTags.push(tag)
        }
      })
    }
    else {
      forEach(tags, (tag) => {
        let isSelectedMCAStatus = tag.isMCA === selectedMCA

        if (isSelectedMCAStatus && isSearchMatch(searchCriteria, tag)) {
          filteredTags.push(tag)
        }
      })
    }

    return filteredTags
  }

  const isSearchMatch = (searchCriteria, tag) => {
    const searchIsEmptyOrMatchesAbbreviation = searchCriteria === '' ? true : tag.abbreviation.includes(searchCriteria)

    return searchIsEmptyOrMatchesAbbreviation || tag.description.toUpperCase().includes(searchCriteria)
  }

  const isSelectedAssortmentFocus = (selectedAssortmentFocusCodes, tag) => {
    // if no selection is made assume that it is a match
    if (selectedAssortmentFocusCodes.length < 1) {
      return true
    }

    // check for 'None' option, if it is not selected and there is a match return true
    if (tag.assortmentFocus) {
      return !selectedAssortmentFocusCodes.includes(0) && selectedAssortmentFocusCodes.includes(tag.assortmentFocus.code)
    }

    // check for the None option and if it is present return true if the tag does not have an assortment focus
    if (selectedAssortmentFocusCodes.includes(0) && !tag.assortmentFocus) {
      return true
    }

    return false
  }

  const getPossibleChannelHierarchyTags = () => {
    let tags = []

    const channelTags = filter(referenceData.tags, tag => {
      const {channel, assortmentFocus, cluster, flow, storeLevel, tier, activeIndicator} = tag

      return activeIndicator && channel && !assortmentFocus && !flow && !cluster && !storeLevel && !tier
    })

    const channelTierTags = filter(referenceData.tags, tag => {
      const {channel, assortmentFocus, cluster, flow, storeLevel, tier, activeIndicator} = tag

      return activeIndicator && channel && !assortmentFocus && !flow && !cluster && !storeLevel && tier
    })

    const channelAssortmentFocusTags = filter(referenceData.tags, tag => {
      const {channel, assortmentFocus, cluster, flow, storeLevel, tier, activeIndicator} = tag

      return activeIndicator && channel && assortmentFocus && !flow && !cluster && !storeLevel && !tier
    })

    const channelAssortmentFocusTierTags = filter(referenceData.tags, tag => {
      const {channel, assortmentFocus, cluster, flow, storeLevel, tier, activeIndicator} = tag

      return activeIndicator && channel && assortmentFocus && !flow && !cluster && !storeLevel && tier
    })

    tags.push(...sortTagsAlphabetically(channelTags))
    tags.push(...sortTagsAlphabetically(channelTierTags))
    tags.push(...sortTagsAlphabetically(channelAssortmentFocusTags))
    tags.push(...sortTagsAlphabetically(channelAssortmentFocusTierTags))

    return tags
  }

  const processExistingTags = () => {
    const existingTagList = {}
    const unifiedProductIds = []

    forEach(selection.products, (offering) => {
      const tags = offering.tagsFor({ regionId, seasonCode })

      if (!unifiedProductIds.includes(offering.unifiedProductId)) {
        unifiedProductIds.push(offering.unifiedProductId)

        tags.tags.forEach((tag) => {
          existingTagList[ tag.bareTag.abbreviation ]
            ? existingTagList[ tag.bareTag.abbreviation ].count++
            : existingTagList[ tag.bareTag.abbreviation ] = { tag: tag.bareTag, count: 1 }
        })
      }
    })

    return existingTagList
  }

  const getFooter = () => {
    return (
      <div className='modal-footer'>
        <div className='modal-footer-container'>
          <NikeButton dataAu='tags-modal-cncl-btn' className='secondary tags-modal-cancel-button' onClick={closeTagsModal}>{format('cancelBtn')}</NikeButton>
          <NikeButton dataAu='tags-modal-btn' className='tags-modal-button' disabled >
            {format('lblUpdateTags')}
          </NikeButton>
        </div>
      </div>
    )
  }

  const closeTagsModal = () => {
    tagModal.close()
  }

  const getColumnOne = () => {
    const { activeTab } = state

    return (
      <div>
        <div className='column-header'>{format('lblFind')}</div>
        <div className='column-content find-container'>
          <span onClick={openChannelTier} className={activeTab === TagTypes.CHANNEL_TIER ? 'active' : ''}>{format('lblChannelTier')}</span>
          <span onClick={openFlow} className={activeTab === TagTypes.FLOW ? 'active' : ''} >{format('lblFlow')}</span>
          <span onClick={openClusters} className={activeTab === TagTypes.CLUSTERS ? 'active' : ''} >{format('lblClusters')}</span>
        </div>
      </div>
    )
  }

  const openChannelTier = () => {
    state.activeTab = TagTypes.CHANNEL_TIER
    tagModal.update()
    console.log('we are here..')
  }

  const openFlow = () => {
    state.activeTab = TagTypes.FLOW
    tagModal.update()
  }

  const openClusters = () => {
    state.activeTab = TagTypes.CLUSTERS
    tagModal.update()
  }

  const getColumnTwo = () => {
    const { activeTab } = state

    return (
      <div>
        <div className='column-header'>{format('lblSelect')}</div>
        <div className='column-content'>
          {activeTab === TagTypes.FLOW &&
          <FlowSelector />}
          {activeTab === TagTypes.CLUSTERS &&
          <ClusterSelector />}
        </div>
      </div>
    )
  }

  const getColumnThree = () => {
    return (
      <div>
        <div className='column-header summary-container'>
          <div>{format('lblSummary')}</div>
          <div className='info-tooltip'>
            <span
              data-au='tags-summary-tooltip'
              data-tag-tooltip={'summary'}
              onClick={handleSummaryToolTipClick}
            >
              <NikeIcon value='info2' size={38} />
            </span>
          </div>
        </div>
        <div className='column-content'>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    )
  }

  const getHeader = () => {
    return (
      <div className='modal-heading' >{format('lblEditTags')}</div>
    )
  }

  const getContent = () => {
    return (
      <div className='tag-modal-container'>
        <AVThreeColumnLayout columnOne={getColumnOne()} columnTwo={getColumnTwo()} columnThree={getColumnThree()} header={getHeader()} footer={getFooter()} showGradient />
      </div>
    )
  }

  const renderSummaryTooltipContent = () => {
    return (
      <div className='tooltip-content'>
        <div>
          <span className='header'>{format('lblTagAll')}</span>
          <span>{format('lblTagAllText')}</span>
        </div>
        <div>
          <span className='header'>{format('lblTagSome')}</span>
          <span>{format('lblTagSomeText')}</span>
        </div>
        <div>
          <span className='header'>{format('lblTagRemove')}</span>
          <span>{format('lblTagRemoveText')}</span>
        </div>
      </div>
    )
  }

  const handleSummaryToolTipClick = () => {
    const anchorSelector = 'span[data-tag-tooltip=summary]'

    state.shouldOpenSummaryTooltip = !state.shouldOpenSummaryTooltip

    if (state.shouldOpenSummaryTooltip) {
      summaryTooltip = NikeFlyout.open({
        content: renderSummaryTooltipContent,
        direction: 'right',
        anchorSelector: anchorSelector,
        showArrow: true,
        arrowSize: 7,
        autoClose: true,
        anchorSpacing: -3,
        className: 'tags-sumamry-tooltip',
        onClose: () => {
          summaryTooltip.unmount()
          summaryTooltip = null
        }
      })
    }
    else {
      summaryTooltip.close()
    }
  }

  state = {
    shouldOpenSummaryTooltip: false,
    activeTab: TagTypes.CHANNEL_TIER,
    seasonCode: seasonCode,
    regionId: regionId,
    selectedProductCodes: selection.productIds,
    selectedTagList: { adds: {}, deletes: {} },
    allowApplyTags: false,
    selectedFilters: { channels: [], tiers: [], assortmentFocuses: [], mca: false, search: '' },
    channelTagOptions: {},
    tierTagOptions: {},
    assortmentFocusTagsOptions: {},
    tagOptions: prepareInitialTagCloudOptions({
      channels: [],
      tiers: [],
      assortmentFocuses: [],
      mca: false,
      search: ''
    }),
    existingTags: processExistingTags(),
    currentAccordion: ''
  }

  let tagModal = NikeModal.open(null, {
    content: getContent,
    large: true,
    dismissable: true,
    className: 'add-or-remove-tags-modal',
    onClose: () => {
      tagModal.unmount()
      closeTagsTooltip()
      tagModal = null
    }
  })
}

export const closeTagsTooltip = () => {
  if (summaryTooltip) {
    summaryTooltip.close()
  }
}

export const loadTagModelTranslations = () => {
  const promises = [
    getTranslations(19, [
      'lblEditTags',
      'lblFind',
      'lblSelect',
      'lblSummary',
      'lblUpdateTags',
      'lblFlow',
      'lblChannelTier',
      'lblClusters',
      'lblTagPanelChannelTagWarning',
      'lblMultiCountRemovedBoardMsg',
      'lblMultiCountRemovedMsg',
      'lblSingleCountRemovedBoardMsg',
      'lblSingleCountRemovedMsg',
      'lblTagAll',
      'lblTagAllText',
      'lblTagSome',
      'lblTagSomeText',
      'lblTagRemove',
      'lblTagRemoveText'
    ]),
    getTranslations(0, [ 'lblClose' ]),
    getTranslations(13, [ 'errAddTagsDefault' ]),
    loadAll()
  ]

  return Promise.all(promises)
}
