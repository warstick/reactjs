import './FlowSelector.scss'
import React from 'react'
import { BareTag } from '@gtm-av/av-tags'
import { loadData } from './FlowSelector.resolver'
import { NikeIcon } from '@gtm-styleguide/react-styleguide'
import { AVTag } from '@gtm-av/av-react-components'
import { format } from '@gtm-av/js-i18n'

export class FlowSelector extends React.Component {
  constructor(props) {
    super(props)
    this.getFlowFromRefData = this.getFlowFromRefData.bind(this)
    this.onToggle = this.onToggle.bind(this)

    this.state = {
      loaded: false
    }
  }

  componentDidMount() {
    this.mounted = true
    loadData().then(() => {
      if (this.mounted) {
        this.setState({
          loaded: true
        })
      }
    })
  }

  componentWillUnmount() {
    this.mounted = false
  }

  onToggle() {}

  render() {
    const { loaded } = this.state
    const flows = this.getFlowFromRefData()

    if (loaded) {
      return (
        <div className='flow-selector'>
          <div className='flow-header'>
            <span>{format('lblFlow')}</span>
            <span className='action-header'>
              <div>Add All</div>
              <div>/</div>
              <div>Remove All</div>
            </span>
          </div>
          <div className='flows-sub-container'>
            <AVTag
              dataAu='tag-modal-select-flow1'
              tag={flows[0]}
              tagState='active'
              onToggle={this.onToggle}
            />
            <AVTag
              dataAu='tag-modal-select-flow2'
              tag={flows[1]}
              tagState='active'
              onToggle={this.onToggle}
            />
            <AVTag
              dataAu='tag-modal-select-flow3'
              tag={flows[2]}
              tagState='active'
              onToggle={this.onToggle}
            />
          </div>
        </div>
      )
    }
    else {
      return (
        <div data-av='tag-modal-accordions'>
          <NikeIcon value='spinner-4' />
        </div>
      )
    }
  }

  getFlowFromRefData() {
    const flowOne = new BareTag({flowId: 1, isMCA: false})
    const flowTwo = new BareTag({flowId: 2, isMCA: false})
    const flowThree = new BareTag({flowId: 3, isMCA: false})

    return [flowOne, flowTwo, flowThree]
  }
}
