import { loadAll } from '@gtm-av/av-reference-data'
import { getTranslations } from '@gtm-av/js-i18n'

const componentId = 19
const translations = [
  'lblFlow'
]

export const loadData = () => {
  const promises = [
    getTranslations(componentId, translations),
    loadAll()
  ]

  return Promise.all(promises)
}
