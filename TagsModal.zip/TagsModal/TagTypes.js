export const TagTypes = Object.freeze({
  CHANNEL_TIER: 'channelTier',
  FLOW: 'flow',
  CLUSTERS: 'clusters'
})
