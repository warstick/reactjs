import './ClusterSelector.scss'
import React from 'react'
import { loadData } from './ClusterSelector.resolver'
import { NikeIcon } from '@gtm-styleguide/react-styleguide'
import { AVTag, AVTagCloud } from '@gtm-av/av-react-components'
import { BareTag } from '@gtm-av/av-tags'
import { format } from '@gtm-av/js-i18n'
import { referenceData } from '@gtm-av/av-reference-data'
import { map } from '@gtm-av/js-iterators'

export class ClusterSelector extends React.Component {
  constructor(props) {
    super(props)
    this.getClusterTags = this.getClusterTags.bind(this)
    this.onToggle = this.onToggle.bind(this)

    this.state = {
      loaded: false
    }
  }

  componentDidMount() {
    this.mounted = true
    loadData().then(() => {
      if (this.mounted) {
        this.setState({
          loaded: true
        })
      }
    })
  }

  componentWillUnmount() {
    this.mounted = false
  }

  onToggle() {}

  render() {
    const { loaded } = this.state

    if (loaded) {
      return (
        <div data-av='tag-panel-accordions'>
          <div data-av='cluster-selector-container'>
            <div className='cluster-selector'>
              <div className='cluster-header'>
                <span>{format('lblSelectClusters')}</span>
                <span className='action-header'>
                  <div>Add All</div>
                  <div>/</div>
                  <div>Remove All</div>
                </span>
              </div>
              <div className='container'>
                <AVTagCloud tagsList={this.getClusterTags()} />
              </div>
            </div>
          </div>
        </div>
      )
    }
    else {
      return (
        <div className='tag-panel-accordions'>
          <NikeIcon value='spinner-4' />
        </div>
      )
    }
  }

  getClusterTags() {
    const clusters = referenceData.clusters.slice(0, 20)

    return map(clusters, (cluster, index) => {
      const clusterTag = new BareTag({clusterCode: cluster.code, isMCA: false})

      return (
        <AVTag
          tag={clusterTag}
          key={`tag-${index}`}
          tagState='active'
          onToggle={this.onToggle}
        />
      )
    })
  }
}
